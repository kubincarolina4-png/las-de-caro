# Las de Caro

Tienda + panel de administración de Las de Caro, en React + Vite.

## Desarrollo local

```bash
npm install
npm run dev
```

## Compilar para producción

```bash
npm run build
npm run preview   # para probar el build localmente
```

## Publicar en GitHub Pages

El workflow en `.github/workflows/deploy.yml` compila y publica automáticamente
cada vez que hacés `push` a la rama `main`. Antes de que funcione, activá esto
una vez en el repositorio:

**Settings → Pages → Source → "GitHub Actions"**

(no "Deploy from a branch" — tiene que decir "GitHub Actions").

Después de eso, cualquier `git push` a `main` compila y publica solo.
La URL va a ser `https://<tu-usuario>.github.io/las-de-caro/`.

## ⚠️ Importante: cómo funciona el almacenamiento acá

Dentro de Claude Artifacts, `window.storage` guardaba los productos e imágenes
en un lugar compartido por todos los que abrían ese artifact. **Fuera de
Claude no existe ese servicio** — este proyecto no tiene backend propio.

Para que el código de `LasDeCaro.jsx` siguiera funcionando *sin tocarlo*,
`src/lib/artifactStorageShim.js` reemplaza `window.storage` por
`localStorage` del navegador. Esto tiene una consecuencia importante:

- **`localStorage` es por navegador, no compartido entre visitantes.**
  Si vos cargás productos desde tu computadora, solo tu computadora los va a
  ver. Alguien que entre a la tienda desde su celular **no va a ver esos
  productos** — su navegador tiene su propio `localStorage` vacío.
- Sirve perfecto para seguir probando y developing en un solo navegador
  (admin y tienda comparten datos entre sí, como hasta ahora).
- **No sirve todavía como tienda real con clientes**, porque cada visitante
  tendría un catálogo vacío o desactualizado.

Para que el catálogo sea de verdad el mismo para todos los visitantes, hace
falta un backend real (por ejemplo Supabase, como se mencionó pero no se
conectó todavía a pedido tuyo). Cuando quieras dar ese paso, avisame.

También tené en cuenta que `localStorage` tiene un límite de tamaño
(típicamente 5–10MB según el navegador) — con fotos de productos comprimidas
alcanza para un catálogo chico/mediano, pero no es ilimitado.
